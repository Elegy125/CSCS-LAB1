﻿using System;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Drawing;
using System.Runtime.InteropServices;
namespace CSCS1
{
    class ReceivingProgram
    {
        static void Main(string[] args)
        {
            ReceiveMessage();
        }
        private static void ReceiveMessage()
        {
            IntPtr handle = GetStdHandle(-11);
            GetConsoleMode(handle, out int mode);
            SetConsoleMode(handle, mode | 0x4);
            int port = 887;
            Commands commands = new Commands();
            UdpClient receiver = new UdpClient(port);
            IPEndPoint remoteIp = new IPEndPoint(IPAddress.Any, 0);
            IPEndPoint iPEndPoint;
            byte commandNum;
            byte command;
            Int16 x0, y0;
            Int16 x1, y1;
            Int16 radius;
            string text;
            string hexcolor;
            Int16 rotation;
            try
            {
                while (true)
                {
                    byte[] data = receiver.Receive(ref remoteIp);
                    commandNum = data[0];
                    switch (commandNum)
                    {
                        case 1:
                            commands.ClearDisplayDecode(data, out command, out
                            hexcolor);
                            Console.WriteLine($"Полученная информация: clear display; цвет: 0x{ hexcolor}; ");
                    break;
                        case 2:
                            commands.PixelDecode(data, out command, out x0, out
                            y0, out hexcolor);
                            Console.WriteLine($"Полученная информация: draw pixel; x: { x0}; y: { y0}; цвет: 0x{ hexcolor}; ");
                    break;
                        case 3:
                            commands.FourNumbersDecode(data, out command, out x0,
                            out y0, out x1, out y1, out hexcolor);
                            Console.WriteLine($"Полученная информация: draw line; x0: { x0}; y0: { y0}; x1: { x1}; y1: { y1}; цвет: 0x{ hexcolor}; ");
                    break;
                        case 4:
                            commands.FourNumbersDecode(data, out command, out x0,
                            out y0, out x1, out y1, out hexcolor);
                            Console.WriteLine($"Полученная информация: draw rectangle; x: { x0}; y: { y0}; ширина: { x1}; высота: { y1}; цвет: 0x{ hexcolor}; ");
                    break;
                        case 5:
                            commands.FourNumbersDecode(data, out command, out x0,
                            out y0, out x1, out y1, out hexcolor);
                            Console.WriteLine($"Полученная информация: fill rectangle; x: { x0}; y: { y0}; ширина: { x1}; высота: { y1}; цвет: 0x{ hexcolor}; ");
                    break;
                        case 6:
                            commands.FourNumbersDecode(data, out command, out x0,
                            out y0, out x1, out y1, out hexcolor); Console.WriteLine($"Полученная информация: draw ellipse; x: { x0}; y: { y0}; радиус x: { x1}; радиус y: { y1}; цвет: 0x{ hexcolor}; ");
                    break;
                        case 7:
                            commands.FourNumbersDecode(data, out command, out x0,
                            out y0, out x1, out y1, out hexcolor);
                            Console.WriteLine($"Полученная информация: fill ellipse; x: { x0}; y: { y0}; радиус x: { x1}; радиус y: { y1}; цвет: 0x{ hexcolor}; ");
                    break;
                        case 8:
                            commands.CircleDecode(data, out command, out x0, out
                            y0, out radius, out hexcolor);
                            Console.WriteLine($"Полученная информация: draw circle; x: { x0}; y: { y0}; радиус: { radius}; цвет: 0x{ hexcolor}; ");
                    break;
                        case 9:
                            commands.CircleDecode(data, out command, out x0, out
                            y0, out radius, out hexcolor);
                            Console.WriteLine($"Полученная информация: fill circle; x: { x0}; y: { y0}; радиус: { radius}; цвет: 0x{ hexcolor}; ");
                    break;
                        case 10:
                            commands.RoundedRectDecode(data, out command, out x0,
                            out y0, out x1, out y1, out radius, out hexcolor);
                            Console.WriteLine($"Полученная информация: draw rounded rectangle; x: { x0}; y: { y0}; width: { x1}; высота: { y1}; радиус: { radius}; цвет:0x{ hexcolor}; ");
                    break;
                        case 11:
                            commands.RoundedRectDecode(data, out command, out x0,
                            out y0, out x1, out y1, out radius, out hexcolor);
                            Console.WriteLine($"Полученная информация: fill rounded rectangle; x: { x0}; y: { y0}; width: { x1}; высота: { y1}; радиус: { radius}; цвет: 0x{ hexcolor}; ");
                    break;
                        case 12:
                            commands.TextDecode(data, out command, out x0, out y0,
                            out hexcolor, out x1, out y1, out text);
                            Console.WriteLine($"Полученная информация: draw text; x: { x0}; y: { y0}; цвет: 0x{ hexcolor}; номер шрифта: { x1}; длина: { y1}; текст: { text}; ");
                    break;
                        case 13:
                            Color[,] colors;
                            commands.ImageDecode(data, out command, out x0, out
                            y0, out x1, out y1, out colors);
                            Console.WriteLine($"Полученная информация: draw image; x: { x0}; y: { y0}; ширина: { x1}; высота: { y1}; colors: ");
                    for (int col = 0; col < y1; col++)
                            {
                                for (int row = 0; row < x1; row++)
                                {
                                    Console.Write("\x1b[38;2;" + colors[row,
                                    col].R + ";" + colors[row, col].G + ";" + colors[row, col].B + "m");
                                    Console.Write("██");
                                }
                                Console.WriteLine("");
                            }
                            Console.WriteLine("");
                            Console.ResetColor();
                            break;
                        case 14:
                            rotation =
                            BitConverter.ToInt16(data.Skip(1).Take(2).ToArray(), 0);
                            Console.WriteLine($"Полученная информация: set orientation; угол поворота: { rotation}; ");
                                break;
                    case 15:
                            Console.WriteLine($"Полученная информация: get width;");
                            data =
                            BitConverter.GetBytes(Convert.ToInt16(Console.WindowWidth));
                            iPEndPoint = new IPEndPoint(remoteIp.Address,
                            remoteIp.Port);
                            Console.WriteLine($"Send: {Console.WindowWidth};");
                            receiver.Send(data, data.Length, iPEndPoint);
                            break;
                        case 16:
                            Console.WriteLine($"Полученная информация: get height;");
                            data =
                            BitConverter.GetBytes(Convert.ToInt16(Console.WindowHeight));
                            iPEndPoint = new IPEndPoint(remoteIp.Address,
                            remoteIp.Port);
                            Console.WriteLine($"Send: {Console.WindowHeight};");
                            receiver.Send(data, data.Length, iPEndPoint);
                            break;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.ReadLine();
            }
            finally
            {
                receiver.Close();
            }
        }
        [DllImport("kernel32.dll", SetLastError = true)]
        public static extern bool SetConsoleMode(IntPtr hConsoleHandle, int mode);
        [DllImport("kernel32.dll", SetLastError = true)]
        public static extern bool GetConsoleMode(IntPtr handle, out int mode);
        [DllImport("kernel32.dll", SetLastError = true)]
        public static extern IntPtr GetStdHandle(int handle);
    }
}
